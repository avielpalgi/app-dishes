import React, { Component } from 'react'
import './about.css';
class About extends Component {
    render() {
        return (
            <div className="about">
                <h1>About</h1>
                <div>sdfsdfsdf</div>
            </div>
        )
    }
}

export default About