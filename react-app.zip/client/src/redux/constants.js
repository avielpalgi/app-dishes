

export const API = 'API';

export const SET_USER_INFO = 'SET_USER_INFO';
export const TOGGLE_LOADER = 'TOGGLE_LOADER';
export const RESET_USER_INFO = 'RESET_USER_INFO';
export const TOOGLE_STOP = 'TOOGLE_STOP';
export const SET_NAVBAR = 'SET_NAVBAR';
export const RESET_NAVBAR = 'RESET_NAVBAR';

