module.exports = {
    SECRET_KEY: 'personalnotessmgrkey'
}